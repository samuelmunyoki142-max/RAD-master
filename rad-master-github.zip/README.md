# RAD MASTER

A responsive medical imaging education website prototype. It runs as a static site with no build step or third-party dependencies.

## Preview locally

Open index.html in a browser, or run a local static server from this directory with: python -m http.server 8000

Then visit http://localhost:8000.

## Publish with GitHub Pages

1. Create a GitHub repository and upload the contents of this project to its root.
2. In the repository, open Settings, then Pages.
3. Choose Deploy from a branch, select the main branch and root folder, then save.
4. GitHub Pages will publish the site and show its URL in the Pages settings.

## Included

- Responsive navigation and modality cards for radiography, ultrasound, CT, MRI, echocardiography, fluoroscopy, cases, and anatomy.
- Searchable radiography reference library grouped by anatomical region.
- Interactive projection guides with preparation, positioning, centring, SID/OID, exposure workflow, collimation, breathing, and image review prompts.
- Image Evaluation Lab checklist and exposure-factor practice question.
- CSS-built RM mark and responsive visual design.

## Project files

- index.html — complete static website (HTML, CSS, and JavaScript).
- README.md — setup and publishing instructions.
- .gitignore — common local editor and operating-system files to exclude.

## Scope and clinical use

This is a front-end educational prototype. Login, registration, dashboard, and course enrollment are visual previews; they do not connect to accounts or save progress. Exposure factors vary with equipment, patient and departmental protocols. Follow approved local technique charts and qualified clinical supervision. This educational resource does not replace clinical judgment.
